PostApp.Collections.Posts = Backbone.Collection.extend({
  comparator: function(post) {
  },

  getOrFetch: function (id) {
  }
});
