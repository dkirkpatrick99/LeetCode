window.PostApp = {
  Models: {},
  Collections: {},
  Views: {},
  Routers: {},
  initialize: function() {
  }
};

Function.prototype.myBind = function myBind (context) {};

JSA = {};

JSA.myCall = function (fn, obj) {};

JSA.myCurry = function (fn, obj, numArgs) {};
