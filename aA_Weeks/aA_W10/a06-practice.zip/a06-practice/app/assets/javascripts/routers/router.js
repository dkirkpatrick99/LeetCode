PostApp.Routers.Router = Backbone.Router.extend({
  initialize: function (options) {
  },

  routes: {
  },

  edit: function (id) {
  },

  index: function () {
  },

  new: function () {
  },

  show: function (id) {
  },

  _swapView: function (view) {
  }
});
